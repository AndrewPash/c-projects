#include <windows.h>
#include <iostream>
using namespace std;
int main()
{
    wchar_t buff[4096];
    GetEnvironmentVariable(L"Path", (wchar_t*)&buff, sizeof(buff));
    wcout << buff;
    Sleep(10000);
}

