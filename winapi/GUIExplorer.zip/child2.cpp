#include <iostream>
#include <windows.h>
#include <string>
using namespace std;
int main(int argc,char *argv[]) {
    string exa = string(argv[1]);
    DWORD byteswritten;
    string dot = "\\*";
    string dir1 = string(argv[0]) + dot;
    WIN32_FIND_DATAA FindFileData;
    HANDLE hFind = FindFirstFileA(dir1.c_str(), &FindFileData);
    if (hFind != INVALID_HANDLE_VALUE) {

        while (FindNextFileA(hFind, &FindFileData)) {

            if (FindFileData.dwFileAttributes != FILE_ATTRIBUTE_DIRECTORY && FindFileData.cFileName != exa)
            {

                cout << FindFileData.cFileName << " ";
               
            }
        }

    }

    FindClose(hFind);
    
    return 0;
}
