#include <iostream>
#include <windows.h>
#include <string>
using namespace std; 




int main(int argc,char * argv[]) {
    string s=string(argv[2]);
    string dot = "*";
    string dir1 = string(argv[0]) + dot;
    const char  srv = '.';
    LPCSTR ptr = dir1.c_str();
    WIN32_FIND_DATAA FindFileData;
    HANDLE hFind = FindFirstFileA(ptr, &FindFileData);
    if (hFind != INVALID_HANDLE_VALUE) {

        while (FindNextFileA(hFind, &FindFileData)) {

            if (FindFileData.dwFileAttributes != FILE_ATTRIBUTE_DIRECTORY && FindFileData.cFileName[0] != srv)
            {
                char buff[4096] = { 0 };
                DWORD bytesread;
                string old = string(argv[0]) + FindFileData.cFileName;
                string nwfile = string(argv[1]) + FindFileData.cFileName;
                string open = string(argv[0]) + FindFileData.cFileName;
                HANDLE hFile = CreateFileA(open.c_str() ,GENERIC_READ,FILE_SHARE_READ, 0, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0);
               
                    ReadFile(hFile, buff, sizeof(buff), &bytesread, NULL);
   
                    char* pch = strtok(buff, " ");
                    while (pch != NULL)
                    {
                        cout << "word" << pch << "word";
                        if (string(pch) == string(argv[4])) {
                            string file = string(argv[3]) + FindFileData.cFileName;
                            if (CreateFileA(file.c_str(), NULL, 0, 0,
                                CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, 0)) {
                                SendMessage(FindWindowA(NULL, s.c_str()), WM_USER + 1, (WPARAM)3, 0);
                            }
                            else {
                                
                                SendMessage(FindWindowA(NULL, s.c_str()), WM_USER + 1, (WPARAM)4, 0);
                            }
                        }
                        pch = strtok(NULL, " ");
                       
                    }

                    if (CopyFileA(old.c_str(), nwfile.c_str(), FALSE)) {
                        SendMessage(FindWindowA(NULL, s.c_str()), WM_USER + 1, (WPARAM)1, 0);
                    }
                    else {
                        SendMessage(FindWindowA(NULL, s.c_str()), WM_USER + 1, (WPARAM)2, 0);
                    }











                }
            }
        }
    
    else {
       
        SendMessage(FindWindowA(NULL, s.c_str()), WM_USER + 1, (WPARAM)5, 0);
    }
   

    FindClose(hFind);
    
    return 0;
}
