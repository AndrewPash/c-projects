#include <Windows.h>
#include <iostream>
#include "atlstr.h"
#include <sstream>
#define BUFSIZE 4096
using namespace std;
LPSTR ptr;
HWND hwnd;
bool check;
STARTUPINFO cif;
HINSTANCE hInst;
PROCESS_INFORMATION pi;

int CALLBACK wWinMain(HINSTANCE hInstance, HINSTANCE, PWSTR szcmdLine, int nCmdShow)
{
    MSG msg{};
    HWND hWnd{};
    static HWND hBtn_CreateSys;
    static HWND hBtn_Copy, hEdit_CopyFrom,hEdit_CopyTo;
    static HWND hBtn_SendEnv, hBtn_SetEnv;
    static HWND hBtn_Info, hBtn_Anon, hEdit_Search1, hEdit_Search2,hEdit_Crt, hEdit_zraz2,hEdit_zraz;
    WNDCLASSEX wc{ sizeof(WNDCLASSEX) };
    wc.cbClsExtra = 0;
    wc.cbWndExtra = 0;

    wc.hCursor = LoadCursor(nullptr, IDC_ARROW);
    wc.hIcon = LoadIcon(nullptr, IDI_APPLICATION);
    wc.hIconSm = LoadIconW(nullptr, IDI_APPLICATION);
    wc.hbrBackground = reinterpret_cast<HBRUSH>(GetStockObject(WHITE_BRUSH));
    wc.hInstance = hInstance;
    hInst = hInstance;
    wc.lpfnWndProc = [](HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)->LRESULT
    {
        switch (uMsg)
        {


        case WM_CREATE: {
            
            hBtn_CreateSys = CreateWindow(L"button", L"�������� ������� ��������", WS_CHILD | WS_VISIBLE, 0, 10,200,20, hWnd, 0, hInst , NULL);
            ShowWindow(hBtn_CreateSys, SW_SHOWNORMAL);
            hBtn_Copy = CreateWindow(L"button", L"��������� �����", WS_CHILD | WS_VISIBLE, 200, 10, 200, 20, hWnd, 0, hInst, NULL);
            ShowWindow(hBtn_Copy, SW_SHOWNORMAL);
            hEdit_CopyFrom = CreateWindow(L"edit", L"����� ��������", WS_CHILD | WS_VISIBLE | ES_RIGHT | WS_BORDER, 200, 50, 200, 20, hWnd, 0, hInst, NULL);
            ShowWindow(hEdit_CopyFrom, SW_SHOWNORMAL);
            hEdit_CopyTo = CreateWindow(L"edit", L"���� ��������", WS_CHILD | WS_VISIBLE | ES_RIGHT | WS_BORDER, 200, 100, 200, 20, hWnd, 0, hInst, NULL);
            ShowWindow(hEdit_CopyTo, SW_SHOWNORMAL);
            hEdit_Crt = CreateWindow(L"edit", L"�� ��������", WS_CHILD | WS_VISIBLE | ES_RIGHT | WS_BORDER, 200, 150, 200, 20, hWnd, 0, hInst, NULL);
            ShowWindow(hEdit_Crt, SW_SHOWNORMAL);
            hEdit_zraz = CreateWindow(L"edit", L"������", WS_CHILD | WS_VISIBLE | ES_RIGHT | WS_BORDER, 200, 200, 200, 20, hWnd, 0, hInst, NULL);
            ShowWindow(hEdit_Crt, SW_SHOWNORMAL);
            hBtn_SetEnv = CreateWindow(L"button", L"������ ����� ��������", WS_CHILD | WS_VISIBLE  , 400, 10, 200, 20, hWnd, 0, hInst, NULL);
            ShowWindow(hBtn_SetEnv, SW_SHOWNORMAL);
            hBtn_Info = CreateWindow(L"button", L"������ ���������� ��� �������� ��������� ������", WS_CHILD | WS_VISIBLE, 600, 10, 400, 20, hWnd, 0, hInst, NULL);
            ShowWindow(hBtn_Info, SW_SHOWNORMAL);
            hBtn_Anon = CreateWindow(L"button", L"����� ����� �� �� ������", WS_CHILD | WS_VISIBLE, 1000, 10, 200, 20, hWnd, 0, hInst, NULL);
            ShowWindow(hBtn_Anon, SW_SHOWNORMAL);
            hEdit_Search2 = CreateWindow(L"edit", L"�� ������", WS_CHILD | WS_VISIBLE | ES_RIGHT | WS_BORDER, 1000, 50, 200, 20, hWnd, 0, hInst, NULL);
            ShowWindow(hEdit_Search2, SW_SHOWNORMAL);
            hEdit_zraz2 = CreateWindow(L"edit", L"������", WS_CHILD | WS_VISIBLE | ES_RIGHT | WS_BORDER, 1000, 100, 200, 20, hWnd, 0, hInst, NULL);
            ShowWindow(hEdit_zraz2, SW_SHOWNORMAL);
            
            return 0;


            break;
        }
        

        case WM_COMMAND:
        {
            HDC hdc;
            hdc = GetDC(hWnd);
            if (lParam == (LPARAM)hBtn_CreateSys) {
                if (!CreateDirectory(L"c:\\FILE11", NULL) ||
                    !CreateDirectory(L"c:\\FILE11\\FILE12", NULL) ||
                    !CreateDirectory(L"c:\\FILE11\\FILE12\\FILE13", NULL) ||
                    !CreateDirectory(L"c:\\FILE21", NULL) ||
                    !CreateDirectory(L"c:\\FILE21\\FILE22", NULL) ||
                    !CreateDirectory(L"c:\\FILE21\\FILE22\\FILE23", NULL))
                {
                    InvalidateRect(hWnd, NULL, TRUE);
                    UpdateWindow(hWnd);
                    TextOutA(hdc, 0, 50, "Error,directory already exists", 30);
                }
                else {
                    InvalidateRect(hWnd, NULL, TRUE);
                    UpdateWindow(hWnd);
                    TextOutA(hdc, 0, 50, "Success", 8);
                }
            }
            if (lParam == (LPARAM)hBtn_Copy) {
                int len1 = GetWindowTextLength(hEdit_CopyFrom) + 1;
                int len2 = GetWindowTextLength(hEdit_CopyTo) + 1 ;
                int len3 = GetWindowTextLength(hWnd) + 1;
                int len4 = GetWindowTextLength(hEdit_Crt) + 1;
                int len5 = GetWindowTextLength(hEdit_zraz) + 1;
                wchar_t *buf1=new wchar_t[len1+1];
                wchar_t* buf2 = new wchar_t[len2+1];
                wchar_t* buf3 = new wchar_t[len3];
                wchar_t* buf4 = new wchar_t[len4];
                wchar_t* buf5 = new wchar_t[len4];
                wstring prob(1, L' ');
                GetWindowText(hEdit_CopyFrom,buf1 ,len1);
                GetWindowText(hEdit_CopyTo, buf2, len2);
                GetWindowText(hWnd, buf3, len3);
                GetWindowText(hEdit_Crt, buf4, len4);
                GetWindowText(hEdit_zraz, buf5, len5);
                wcsncat(buf1, prob.c_str(), len1);
                wcsncat(buf1, buf2, len1 + len2);
                wcsncat(buf1, prob.c_str(), len1 + len2);
                wcsncat(buf1, buf3, len1 + len2+ len3);
                wcsncat(buf1, prob.c_str(), len1 + len2 + len3);
                wcsncat(buf1, buf4, len1 + len2 + len3 + len4);
                wcsncat(buf1, prob.c_str(), len1 + len2 + len3+len4);
                wcsncat(buf1, buf5, len1 + len2 + len3 + len4+len5);
                CreateProcess(L"C:\\Users\\Andrey\\source\\repos\\Project12\\Debug\\Project12.exe", buf1 , NULL, NULL, TRUE, NULL, NULL, NULL, &cif, &pi);
                break;
            }
            if (lParam == (LPARAM)hBtn_Anon) {
                char text[256];
                HANDLE readp, writep, writed;
                SECURITY_ATTRIBUTES sa;
                sa.bInheritHandle = true;
                sa.lpSecurityDescriptor = NULL;
                if (CreatePipe(&readp, &writep, &sa, 0)) {
                    TextOutA(hdc, 0, 300, "Pipe 1 created", 15);

                }
                else {
                    DWORD err = GetLastError();
                    sprintf(text, "%d", err);
                    TextOutA(hdc, 0, 300, text, 2);

                }
                ZeroMemory(&cif, sizeof(STARTUPINFO));
                cif.hStdOutput = writep;
                cif.dwFlags = STARTF_USESTDHANDLES | STARTF_USESHOWWINDOW;
                int len = GetWindowTextLength(hEdit_Search2) + 1;
                int len1 = GetWindowTextLength(hEdit_zraz2) + 1;
                wchar_t* buf = new wchar_t[len];
                wchar_t* buf1 = new wchar_t[len1];
                GetWindowText(hEdit_Search2, buf, len);
                GetWindowText(hEdit_zraz2, buf1, len1);
                wstring prob(1, L' ');
                wcsncat(buf, prob.c_str(), len+1);
                wcsncat(buf, buf1, len + len1+1);
                CreateProcess(L"C:\\Users\\Andrey\\source\\repos\\Project11\\Debug\\Project11.exe", buf, NULL, NULL, TRUE, CREATE_NEW_CONSOLE, NULL, NULL, &cif, &pi);
                CloseHandle(writep);
                DWORD bytesread;
                char buff[4096] = { 0 };
                int n=150;
                ReadFile(readp, buff, sizeof(buff), &bytesread, NULL);
                char* pch = strtok(buff," "); 
                InvalidateRect(hWnd, NULL, TRUE);
                UpdateWindow(hWnd);
                while (pch != NULL)                         
                {
                    TextOutA(hdc, 1000, n, pch, strlen(pch));
                    pch = strtok(NULL," ");
                    n = n + 20;
                }
                
                break;
                
            }
            if (lParam ==(LPARAM)hBtn_SetEnv) {
                TCHAR buff[128];
                LPTSTR pszOldVal;
                CreateProcess(L"C:\\Users\\Andrey\\source\\repos\\Project13\\Debug\\Project13.exe", NULL, NULL, NULL, TRUE, CREATE_NEW_CONSOLE, NULL, NULL, &cif, &pi);
                Sleep(5000);
                pszOldVal = (LPTSTR)malloc(BUFSIZE * sizeof(TCHAR));
                GetEnvironmentVariable(L"Path", pszOldVal, 128);
                SetEnvironmentVariable(L"Path", L"c:\\FILE11");
                CreateProcess(L"C:\\Users\\Andrey\\source\\repos\\Project13\\Debug\\Project13.exe", NULL, NULL, NULL, TRUE, CREATE_NEW_CONSOLE, NULL, NULL, &cif, &pi);
                SetEnvironmentVariable(L"Path", pszOldVal);
            }
            if (lParam == (LPARAM)hBtn_Info) {
                HDC hdc;
                hdc = GetDC(hWnd);
                string info,hproc,hthr,pid,tid;
                stringstream hpro,hth,pids,ti;
                hpro << pi.hProcess;
                hpro >> hproc;
                hth << pi.hThread;
                hthr=hth.str();
                pids << pi.dwProcessId;
                pid=pids.str();
                ti << pi.dwThreadId;
                tid=ti.str();
                info = "Process handle:" + hproc + "," + "Thread handle:" + hthr + "," + "Process id:" + pid + "," + "Thread id:" + tid;
                const int size = info.length();
                char *inf=new char[size+1];
                strcpy(inf, info.c_str());
                int n = 50;
                char* pch = strtok(inf, ",");
                while (pch != NULL) {
                    TextOutA(hdc, 800, n, pch, strlen(pch));
                    pch= strtok(NULL, ",");
                    n = n + 50;
                }
                
                
            }
            
            break;
            
        }

        case WM_USER+1:
        {
            HDC hdc;
            hdc = GetDC(hWnd);
            switch ((int)lParam) {
            case 1:
            {
                InvalidateRect(hWnd, NULL, TRUE);
                UpdateWindow(hWnd);
                TextOutA(hdc, 200, 500, "Successfully copied", 19);
                break;
            }
            case 2: {
                InvalidateRect(hWnd, NULL, TRUE);
                UpdateWindow(hWnd);
                TextOutA(hdc, 200, 500, "Copy error",10);
                break;
            }
            case 3:
            {
                InvalidateRect(hWnd, NULL, TRUE);
                UpdateWindow(hWnd);
                TextOutA(hdc, 200, 550, "Successfully created", 20);
                break;
            }
            case 4: {
                InvalidateRect(hWnd, NULL, TRUE);
                UpdateWindow(hWnd);
                TextOutA(hdc, 200, 550, "Creation error",14);
                break;

            }
            }
            break;
        }




        case WM_CLOSE:
        {


            if (MessageBox(hWnd, L"�� ����� ������ �����?", L"³��� ������", MB_OKCANCEL) == IDOK)
            {
                PostQuitMessage(0);
            }
        }
        return 0;
        }
        return DefWindowProc(hWnd, uMsg, wParam, lParam);
    

    };
    wc.lpszClassName = L"App";
    wc.lpszMenuName = nullptr;
    wc.style = CS_VREDRAW | CS_HREDRAW;


    if (!RegisterClassEx(&wc))
        return EXIT_FAILURE;


    if (hWnd = CreateWindow(wc.lpszClassName, L"winapi3",  WS_OVERLAPPEDWINDOW , CW_USEDEFAULT, 0, 1500,700, nullptr, nullptr, wc.hInstance, nullptr); hWnd == INVALID_HANDLE_VALUE)
        return EXIT_FAILURE;

    ShowWindow(hWnd,nCmdShow
    );
    UpdateWindow(hWnd);

    while (GetMessage(&msg, hWnd, 0, 0))
    {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }
    return static_cast<int>(msg.wParam);
}
